# Sibusiso Electrical & Plumbing Services - Website Project

**Module:** WEDE5020 | Website Project | Part 1
**Chosen organisation:** Sibusiso Electrical & Plumbing Services (Proposal 2)

---

## Student Information

| Field | Detail |
|---|---|
| Student | Theolin Chetty |
| Student Number | ST10507916 |
| Module Code | WEDE5020 |
| Lecturer | Mr. J. Sookha |
| Submission | Part 1 |

---

## Project Overview

Sibusiso Electrical & Plumbing Services is a small, owner-run business
providing electrical and plumbing repairs and installations to homes and
small businesses across Johannesburg, Gauteng. It is a **hypothetical
business created for this assignment**, modelled on real South African
sole-trader electrical/plumbing services (see the *Website Project
Proposal* document, Proposal 2, for the original brief this build is based
on).

Almost all of the business's work currently comes from word-of-mouth
referrals - the organisation has no dedicated website. This project builds
that first website: a central, mobile-friendly online presence that lets
new customers find the business, understand what it offers, and request a
quote or emergency call-out as easily as an existing customer can phone in.

This repository (Part 1) contains the initial site structure, all planned
HTML pages with real content, shared CSS/JS, and the supporting research
and planning documents.

---

## Website Goals and Objectives

- Build trust and make the business look established and professional online.
- Clearly explain electrical and plumbing services and the areas served.
- Generate quote requests and emergency call-out enquiries through a simple form.
- Place contact options (phone, WhatsApp, email, quote form) in highly visible locations on every page.
- Support mobile users, who may be searching for a tradesperson while away from a desktop computer.
- Use testimonials and a project gallery to reinforce credibility.

---

## Key Features and Functionality

- Responsive, mobile-first layout (CSS Grid + Flexbox, one shared stylesheet).
- Sticky header with a hamburger menu on mobile and a full horizontal menu on desktop (`js/script.js`).
- Homepage hero with a clear call to action ("Request a Free Quote" / click-to-call).
- Services page separating **Electrical**, **Plumbing**, and **Emergency Call-Out** offerings.
- Project **Gallery** with category-tagged project cards (additional page - see *Additional Pages* below).
- **Testimonials** page with star ratings and customer quotes (additional page - see below).
- **Enquiry** page with a validated quote/call-out request form (service type, suburb, preferred date, job description).
- **Contact** page with **two** physical locations (Johannesburg CBD head office + Randburg depot), each with its own embedded map, plus a general contact form.
- Client-side form validation with inline error messages and a success confirmation (no backend yet - see *Part 1 Details*).
- Semantic HTML5 (`header`, `nav`, `main`, `section`, `article`, `footer`) throughout, with code comments explaining each section.
- Photography for the hero, About page, team portraits, and all six Gallery cards, plus original SVG icons (logo, service icons) - see *Content Research and Sourcing*.

---

## Timeline and Milestones

*(Adapted from Proposal 2, section 7 "Timeline and Milestones".)*

| Week | Milestone |
|---|---|
| Week 1 | Client requirements, service inventory, sitemap, content plan, wireframes |
| Week 2 | Visual design and development of Home and Services pages |
| Week 3 | Gallery, Testimonials, Contact, quote form, responsive behaviour, content integration |
| Week 4 | Usability testing, accessibility checks, corrections, performance testing, client review, deployment |

---

## Part 1 Details

Part 1 covers:

1. **Content research and sourcing** - organisation research, written page
   copy, and image/icon assets, organised in `../02-Content-Research/`
   (images, documents, text subfolders per page).
2. **Website structure and planning** - sitemap (see below) and the file/
   folder structure required by the brief.
3. **HTML structure and basic content** - all pages built with semantic
   HTML5, integrated content, working navigation, comments, and consistent
   indentation.
4. **Testing and debugging** - pages were run through HTML-Tidy validation
   and visually tested at mobile (375px), tablet (700px), and desktop
   (1280px) widths; the mobile nav toggle and both forms (Enquiry, Contact)
   were interaction-tested (see *Changelog*).

*Part 2 and Part 3 (further functionality, refinement, and deployment)
will follow in future submissions/edits, per the assignment brief.*

### Additional Pages (beyond the required minimum of 5)

The brief requires a **minimum of 5 pages**: Home, About Us, Services,
Enquiry, Contact. This build includes **7 pages** - the 5 required pages,
plus two extra pages proposed directly in Proposal 2, section 4:

- `gallery.html` - before/after style project cards ("before-and-after
  project photographs" in Proposal 2).
- `testimonials.html` - customer reviews ("testimonials... to reinforce
  credibility" in Proposal 2).

Both are linked from the main navigation and the footer on every page.

### Images and Content Sourcing Note

Per the assignment brief, section 3.1, the site uses royalty-free
photography for the hero image, the About page story image, the three
team portraits, and all six Gallery project cards (11 photos in total).
This sandbox's network could not reach stock-photo CDNs directly, so the
photos were supplied by the student and converted/placed into the site
structure. Keep a record of each photo's exact source URL and licence
(e.g. Pexels License) for the Harvard reference list, since that detail
isn't recoverable from the image file itself.

The small circular icons throughout the site (electrical bolt, plumbing
drop, phone, clock, shield, etc.) and the logo remain original, hand-built
SVG graphics in the site's navy/white/safety-yellow theme - original
content is explicitly permitted by the brief, and icons are conventionally
illustrated rather than photographed.

---

## Sitemap

![Website sitemap diagram](images/sitemap-diagram.png)

```
Home (index.html)
 ├── About Us (about.html)
 ├── Services (services.html)
 ├── Gallery (gallery.html)            *additional page
 ├── Testimonials (testimonials.html)  *additional page
 ├── Enquiry (enquiry.html)
 └── Contact (contact.html)
```

The global navigation menu (Home · About Us · Services · Gallery ·
Testimonials · Enquiry · Contact) appears identically on every page, so any
page is reachable in a single click from anywhere on the site.

---

## File and Folder Structure

```
03-Website/                 <- website root (this folder)
├── index.html
├── about.html
├── services.html
├── gallery.html            (additional page)
├── testimonials.html       (additional page)
├── enquiry.html
├── contact.html
├── README.md
├── css/
│   └── style.css
├── js/
│   └── script.js
└── images/
    ├── logo.svg (icon only)
    ├── icon-*.svg (electrical, plumbing, emergency, quote, location, phone, clock, shield, cash)
    ├── hero-photo.jpg, about-story-photo.jpg (photography)
    ├── team-sibusiso-nkosi.jpg, team-precious-dlamini.jpg, team-kabelo-mahlangu.jpg (photography)
    ├── gallery-full-house-rewire.jpg, gallery-db-board-upgrade.jpg,
    │   gallery-burst-geyser-repair.jpg, gallery-bathroom-renovation.jpg,
    │   gallery-commercial-maintenance.jpg, gallery-outdoor-tap-irrigation.jpg (photography)
    └── sitemap-diagram.png
```

A companion folder outside the website root, `02-Content-Research/`,
holds the source research: `images/` (organised per page), `documents/`
(sitemap source files), and `text/` (page-by-page content notes with
sources), as required by section 3 of the brief. The `01-Proposal-Document/`
folder holds the Website Project Proposal Word document (section 7.1).

---

## Changelog

| Date | Change |
|---|---|
| 2026-09-01 | Initial Part 1 build: project folder structure, content research, sitemap diagram, all 7 HTML pages, shared CSS/JS, README, and Website Project Proposal document created. |
| 2026-09-01 | Removed em dashes across all files. Replaced the hero image, About page story image, three team portraits, and all six Gallery project images with real photography (11 photos total), supplied by the student; icons and logo remain original SVG graphics. |

---

## References (Harvard Style)

*(Reused from the original WEDE5020 Part 1 "Target Organisation Proposals"
document - Theolin Chetty, ST10507916, 29 August 2026 - since these same
web standards govern the HTML/CSS/JS build in this repository.)*

MDN Web Docs (2025) *Responsive web design*. Available at: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design (Accessed: 29 August 2026).

Nielsen Norman Group (2024) *10 usability heuristics for user interface design*. Available at: https://www.nngroup.com/articles/ten-usability-heuristics/ (Accessed: 29 August 2026).

WHATWG (2026) *HTML Living Standard*. Available at: https://html.spec.whatwg.org/ (Accessed: 29 August 2026).

World Wide Web Consortium (W3C) (2024) *Web Content Accessibility Guidelines (WCAG) 2.2*. Available at: https://www.w3.org/TR/WCAG22/ (Accessed: 24 August 2026).

World Wide Web Consortium (W3C) (2024) *Understanding WCAG 2.2*. Available at: https://www.w3.org/WAI/WCAG22/Understanding/ (Accessed: 26 August 2026).

World Wide Web Consortium (W3C) (2024) *ARIA Authoring Practices Guide*. Available at: https://www.w3.org/WAI/ARIA/apg/ (Accessed: 25 August 2026).

Google for Developers (2025) *SEO Starter Guide*. Available at: https://developers.google.com/search/docs/fundamentals/seo-starter-guide (Accessed: 23 August 2026).

Mozilla Developer Network (MDN) Web Docs (2025) *CSS: Cascading Style Sheets*. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS (Accessed: 24 August 2026).

OpenStreetMap Contributors (2026) *OpenStreetMap embeddable map*. Available at: https://www.openstreetmap.org/export/embed.html (Accessed: 1 September 2026). - *used for the two location maps on contact.html.*
