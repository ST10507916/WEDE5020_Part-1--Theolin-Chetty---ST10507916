CONTENT RESEARCH AND SOURCING - Sibusiso Electrical & Plumbing Services
WEDE5020 | Website Project | Part 1 | Theolin Chetty | ST10507916

This folder is the deliverable for assignment section 3 ("Content Research
and Sourcing") and 7.2 ("Content Research and Sourcing: Submit a
compressed ZIP file containing all relevant researched content").

FOLDER STRUCTURE
----------------
images/       Original graphics used across the site, organised by the
              page they belong to (home, about, services, gallery,
              testimonials, enquiry, contact) plus a shared icons/
              subfolder. See "Image sourcing note" below.
documents/    Planning documents - the visual sitemap (SVG + PNG).
text/         Page-by-page written content, one .txt file per page, each
              ending with a SOURCE note explaining which parts come
              directly from Proposal 2 of the original two-proposal
              submission and which parts are original content written
              for this assignment.

IMAGE SOURCING NOTE
--------------------
Per assignment brief 3.1, the site uses royalty-free photography (11
photos) for the homepage hero, the About page story image, the three team
portraits, and all six Gallery project cards. This student sandbox's
network only permits a small allowlist of domains, so direct downloads
from stock-photo CDNs could not be performed from within the sandbox;
the photos were supplied by the student and placed into the site
structure and this research folder. Record each photo's exact source URL
and licence (e.g. Pexels License) for the Harvard reference list.

The small circular icons (electrical, plumbing, phone, clock, shield,
etc.) and the logo remain original, hand-authored SVG graphics in the
site's navy/white/safety-yellow theme - explicitly permitted by the brief
as "Original Content," and conventional for icon-style UI elements.

CONTENT SOURCES
----------------
- Proposal 2 ("PROPOSAL 2: SIBUSISO ELECTRICAL & PLUMBING SERVICES"),
  WEDE5020 Part 1, Theolin Chetty, ST10507916 - organisation overview,
  goals, proposed features, design direction, and technical requirements.
- Original student-authored copy - page headlines, team bios, service
  descriptions, gallery project write-ups, and sample testimonials,
  written to represent a realistic small Johannesburg trade business.
- See the Harvard Style Reference List in README.md (website folder) and
  the Website Project Proposal document for web-standards references
  (MDN, W3C/WCAG, WHATWG, Google, OpenStreetMap).
